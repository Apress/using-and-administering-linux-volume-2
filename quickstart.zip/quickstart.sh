#!/bin/bash
################################################################################
#                              quickstart.sh                                   #
#                                                                              #
# This script is for use by students taking the "Using and Administering Linux #
# - Zero to SysAdmin" self-study course.                                       #
#                                                                              #
# This script is intended to enable the student to configure a brand new VM    #
# created using the Fedora Linux Xfce ISO image to the approximate state of    #
# the StudentVM1 virtual machine at the beginning of Volume 2 or Volume 3.     #
#                                                                              #
# WARNING: THIS SCRIPT SHOULD NOT BE USED FOR ANY OTHER PURPOSE.               #
#                                                                              #
#                                                                              #
# Change History                                                               #
# 10/30/2019  David Both    Original code.                                     #
#                                                                              #
#                                                                              #
#                                                                              #
#                                                                              #
#                                                                              #
#                                                                              #
#                                                                              #
################################################################################
################################################################################
################################################################################
#                                                                              #
#  Copyright (C) 2007, 2019 David Both                                         #
#  LinuxGeek46@both.org                                                        #
#                                                                              #
#  This program is free software; you can redistribute it and/or modify        #
#  it under the terms of the GNU General Public License as published by        #
#  the Free Software Foundation; either version 2 of the License, or           #
#  (at your option) any later version.                                         #
#                                                                              #
#  This program is distributed in the hope that it will be useful,             #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of              #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               #
#  GNU General Public License for more details.                                #
#                                                                              #
#  You should have received a copy of the GNU General Public License           #
#  along with this program; if not, write to the Free Software                 #
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA   #
#                                                                              #
################################################################################
################################################################################
################################################################################

################################################################################
# Help                                                                         #
################################################################################
Help()
{
   # Display Help
   echo "################################################################################"
   echo "#                              quickstart.sh                                   #"
   echo "#                                                                              #"
   echo "# This script is for use by students taking the \"Using and Administering Linux #"
   echo "# - Zero to SysAdmin\" self-study course.                                       #"
   echo "#                                                                              #"
   echo "# This script is intended to enable the student to configure a brand new VM    #"
   echo "# created using the Fedora Linux Xfce ISO image to the approximate state of    #"
   echo "# the StudentVM1 virtual machine at the beginning of Volume 2 or Volume 3.     #"
   echo "#                                                                              #"
   echo "# This Bash script also verifies that the virtual machine host is configured   #"
   echo "# properly and that Fedora release 29 or later is installed.                   #"
   echo "#                                                                              #"
   echo "################################################################################"
   echo "# WARNING: THIS SCRIPT WILL DELETE OR OVERWRITE ALL PARTITIONS ON ALL STORAGE  #"
   echo "#          DEVICES EXCEPT FOR /dev/sda. THIS WILL DELETE ALL OF THE DATA ON    #"
   echo "#          THOSE DEVICES.                                                      #"
   echo "#------------------------------------------------------------------------------#"
   echo "# WARNING: THIS PROGRAM WILL ALSO DELETE ALL STUDENT USERS AND THEIR DATA, AS  #"
   echo "#          WELL AS OTHER DATA AND PROGRAMS THAT MIGHT BE INSTALLED ON THIS     #"
   echo "#          HOST.                                                               #"
   echo "#------------------------------------------------------------------------------#"
   echo "# WARNING: DO NOT USE THIS SCRIPT ON A PRODUCTION HOST OR VM!                  #"
   echo "#------------------------------------------------------------------------------#"
   echo "# WARNING: DO NOT USE THIS SCRIPT IF YOU ARE STARTING THIS COURSE WITH         #"
   echo "#          VOLUME 1. IT IS NOT REQUIRED IN THAT CASE.                          #"
   echo "################################################################################"
   echo "#                                                                              #"
   echo "# Syntax: quickstart.sh -v[h|g][2|3|c]                                         #"
   echo "# 2     Configure StudentVM1 to the start of Volume 2.                         #"
   echo "# 3     Configure StudentVM1 to the start of Volume 3.                         #"
   echo "#       This option also sets the state for Volume 2.                          #"
   echo "#                                                                              #"
   echo "# c     Remove all software and filesystems to return this VM to a state       #"
   echo "#       of the newly installed VM prior to running any experiments in          #"
   echo "#       in Volume 1 of this course. Use this option only if you need to return #"
   echo "#       the host to a pristine state.                                          #"
   echo "#                                                                              #"
   echo "# g     Print the GPL license notification.                                    #"
   echo "# h     Print this Help to STDOUT and exit.                                    #"
   echo "# v     Set verbose mode. Displays helpful messages to STDOUT and exit.        #"
   echo "# V     Print the software version number to STDOUT and exit.                  #"
   echo "#                                                                              #"
   echo "################################################################################"
}

################################################################################
# Print the GPL license header                                                 #
################################################################################
gpl()
{
   echo
   echo "################################################################################"
   echo "#  Copyright (C) 2007, 2019  David Both                                        #"
   echo "#  http://www.both.org                                                         #"
   echo "#                                                                              #"
   echo "#  This program is free software; you can redistribute it and/or modify        #"
   echo "#  it under the terms of the GNU General Public License as published by        #"
   echo "#  the Free Software Foundation; either version 2 of the License, or           #"
   echo "#  (at your option) any later version.                                         #"
   echo "#                                                                              #"
   echo "#  This program is distributed in the hope that it will be useful,             #"
   echo "#  but WITHOUT ANY WARRANTY; without even the implied warranty of              #"
   echo "#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               #"
   echo "#  GNU General Public License for more details.                                #"
   echo "#                                                                              #"
   echo "#  You should have received a copy of the GNU General Public License           #"
   echo "#  along with this program; if not, write to the Free Software                 #"
   echo "#  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA   #"
   echo "################################################################################"
   echo
}

################################################################################
# Quit nicely with messages as appropriate                                     #
################################################################################
Quit()
{
   if [ $error -gt 0 ]
   then
      error=0
      Msg="Errors ecountered. Correct the listed errors, restart the VM and re-run this program."
      PrintMsg
   fi
   exit $error
}

################################################################################
# Gets simple (Y)es (N)o (Q)uit response from user. Loops until                #
# one of those responses is detected.                                          #
################################################################################
ynq()
{
   # loop until we get a good answer and break out
   while [ $OK = 0 ]
     do
        # Print the message
        echo -n "$Msg (ynq) "
        # Now get some input
        read input
        # Test the input
        if [ $input = "yes" ] || [ $input = "y" ]
        then
           response="y"
           OK=1
        elif [ $input = "no" ] || [ $input = "n" ]
        then
           response="n"
           OK=1
           Quit
        elif [ $input = "help" ] || [ $input = "h" ]
        then
           help
        elif [ $input = "q" ] || [ $input = "quit" ]
        then
           Quit
        else
           # Invalid input
           echo "INPUT ERROR: Must be y or n or q in lowercase. Please try again."
        fi
      done
}



################################################################################
# Display verbose messages in a common format                                  #
################################################################################
PrintMsg()
{
   if  [ $verbose = 1 ] && [ -n "$Msg" ] 
   then
      echo "## $Msg: Error number $error "
      # Set the message to null
      Msg=""
   elif [ $verbose = 1 ] && [ -n "$Msg" ]
   then
      echo "## $Msg"
   fi
}

################################################################################
# Set user ID and directory                                                    #
################################################################################
SetUser()
{
   # Here we set some user directory variables for use while creating the
   # user accounts and directories and some contained files.
   UserDir="/home/$User"
}

################################################################################
# Set file ownership in $UserDir 
################################################################################
SetOwnership()
{
   for User in $StudentList
   do
      SetUser
      cd $UserDir
      chown -R $User.$User *
   done
}

################################################################################
# Get Distribution name and release level                                      #
################################################################################
GetDistro()
{
   #---------------------------------------------------------------------------
   # Get the host physical architecture
   HostArch=`echo $HOSTTYPE | tr [:lower:] [:upper:]`
   #---------------------------------------------------------------------------
   # Get some information from the *-release file. We care about this to give
   # us the Fedora version number.
   #---------------------------------------------------------------------------
   # Switch to /etc for now
   cd /etc
   # Look for Fedora in the os-release file
   if grep -i "NAME=Fedora" os-release > /dev/null
   then
      # This is Fedora
      Name="fedora"
      # Define the Distribution
      Distro=`grep PRETTY_NAME  os-release | awk -F= '{print $2}' | sed -e "s/\"//g"`
      # Get the full release number
      Release=`grep VERSION_ID os-release | awk -F= '{print $2}'`
      #---------------------------------------------------------------------------
      # Verify Fedora release $MinRelease= or above. This is due to the lack 
      # of Fedora and Fusion repositories prior to that release.
      #---------------------------------------------------------------------------
      if [ $Release -lt $MinRelease ]
      then
         Msg="Release $Release of Fedora is not supported. Only releases $MinRelease and above are supported."
         PrintMsg
         error=98
         Quit 
      fi
   else
         Msg="This is not Fedora. This script is intended only for Fedora."
         PrintMsg
         error=99
         Quit 
   fi
} # end GetDistro

################################################################################
################################################################################
# Main program                                                                 #
################################################################################
################################################################################
# Set initial variables
badoption=0
Clean=0
CPUs=0
DiskSize=0
Distro="fedora"
error=0
Host="studentvm1"
HostName=`hostname`
InstalledMemory=0 # In Kb
IP="0.0.0.0"
MinMemory=4000000 # In KB
MinCPUs=2
MinRelease=29
Msg=""
Name=""
OK=0
Password="password"
PkgMgr="dnf"
RC=0
Release=0
response=""
RPMlist1="tilix screen ksh tcsh zsh sysstat pwgen vim-enhanced htop atop iotop lshw lm_sensors hddtemp smartmontools tilix lxterminal konsole5 rxvt terminator lxdm xorg-x11-xdm compiz fvwm fluxbox icewm"
RPMlist2="mc krusader atop htop glances cups-pdf a2ps lshw sipcalc iptraf-ng logwatch telnet-server xinetd iptables-services fail2ban gamin"
SDAsize=60
SDAok=0
SDBsize=20
SDBok=0
SDCsize=2
SDCok=0
SDDsize=2
SDDok=0
StudentList="student student1 student2 tuser1 tuser2 tuser3 tuser5"
SwapVol=`swapon -s | grep dm- | awk '{print $1}'`
Test=0
User=""
UserDir=""
verbose=0
version=00.90
V2="0"
V3="0"


################################################################################
# Some sanity checks
################################################################################
#------------------------------------------------------------------------------#
# Check for root. 
#------------------------------------------------------------------------------#

if [ `id -u` != 0 ]
then
   Msg="ERROR! You must be the root user to run this program"
   verbose=1
   PrintMsg
   error=1
   Quit
fi


################################################################################
# Process the input options. Add options as needed.                            #
################################################################################
# Get the options
while getopts ":cghtvV23" option; do
   case $option in
      2) # Configure for start of Volume 2
         V2="1";;
      3) # Configure for start of Volume 3
         V2="1"
         V3="1";;
      g) # display GPL
         gpl
         Quit;;
      t) # Set test mode - a hidden option
         Test=1;;
      v) # Set verbose mode
         verbose=1;;
      V) # Print software version and exit
         echo "Version = $version"
         Quit;;
      h) # display Help
         Help
         Quit;;
      c) # Clean the system - a hidden option
         Clean=1;;
     \?) # incorrect option
         badoption=1;;
   esac
done

if [ $badoption = 1 ]
then
   echo "ERROR! Invalid option"
   Help
   verbose=1
   error=2
   Quit
fi

################################################################################
# Check for Fedora and version
################################################################################
GetDistro

if [ $Test = 1 ] || [ $verbose = 1 ]
then
   Msg="The host physical architecture is $HostArch"
   PrintMsg
   Msg="Name = $Name"
   PrintMsg
   Msg="Distro = $Distro"
   PrintMsg
   Msg="Current release = $Release"
   PrintMsg
fi

################################################################################
# Print help with warning and verify the user wants to continue.
################################################################################
Help 
Msg="y = Yes, n = No, q = Quit"
ynq


################################################################################
# Do a bit of verification to ensure that the VM is correctly configured
################################################################################
#------------------------------------------------------------------------------#
# Start with the IP address range which should be 10.0.2.*/24
#------------------------------------------------------------------------------#
IP=`ip addr | grep "inet 10" | awk '{print $2}'`
if ! echo $IP | grep 10.0.2.*/24  > /dev/null
then
   error=3
   Msg="ERROR!  The IP address, $IP, for this VM is incorrect."
   PrintMsg
   error=0
   Msg="        It must be in the range of 10.0.2.0/24."
   PrintMsg
fi   

################################################################################
# Check the virtual disk presence and sizes
################################################################################
# Note: This could be improved by making it a loop and / or procedure
#------------------------------------------------------------------------------#
# Start with /dev/sda but since it must exist we only need to check the size
#------------------------------------------------------------------------------#
# Check size of /dev/sda
DiskSize=`lsblk | grep sda | head -n 1 | awk '{print $4}' | sed -e "s/G//"`
if [ $DiskSize -lt $SDAsize ]
then
   Msg="ERROR!  The disk /dev/sda is too small. It is $DiskSize G and it should be at least $SDAsize G."
   error=4
   PrintMsg
fi   
   
#------------------------------------------------------------------------------#
# Check /dev/sdb
#------------------------------------------------------------------------------#
# Check presence of /dev/sdb
if ! lsblk | grep sdb > /dev/null
then
   Msg="ERROR!  The virtual disk /dev/sdb does not exist. You must create it with $SDBsize GB of space."
   error=5
   PrintMsg
fi

# Check size of /dev/sdb
DiskSize=`lsblk | grep sdb | head -n 1 | awk '{print $4}' | sed -e "s/G//"`
if [ $DiskSize -lt $SDBsize ]
then
   Msg="ERROR!  The disk /dev/sdb is too small. It is $DiskSize G and it should be at least $SDBsize G."
   error=6
   PrintMsg
fi   
   
#------------------------------------------------------------------------------#
# Check /dev/sdc
#------------------------------------------------------------------------------#
# Check presence of /dev/sdc
if ! lsblk | grep sdc > /dev/null
then
   Msg="ERROR!  The virtual disk /dev/sdc does not exist. You must create it with 2GB of space."
   error=7
   PrintMsg
fi

# Check size of /dev/sdc
DiskSize=`lsblk | grep sdc | head -n 1 | awk '{print $4}' | sed -e "s/G//"`
if [ $DiskSize -lt $SDCsize ]
then
   Msg="ERROR!  The disk /dev/sdc is too small. It is $DiskSize G and it should be at least $SDCsize G."
   error=8
   PrintMsg
fi   
   
#------------------------------------------------------------------------------#
# Check /dev/sdd
#------------------------------------------------------------------------------#
# Check presence of /dev/sdd
if ! lsblk | grep sdd > /dev/null
then
   Msg="ERROR!  The virtual disk /dev/sdd does not exist. You must create it with $SDDsize GB of space."
   error=9
   PrintMsg
fi

# Check size of /dev/sdd
DiskSize=`lsblk | grep sdd | head -n 1 | awk '{print $4}' | sed -e "s/G//"`
if [ $DiskSize -lt $SDDsize ]
then
   Msg="ERROR!  The disk /dev/sdd is too small. It is $DiskSize G and it should be at least $SDDsize G."
   error=10
   PrintMsg
fi   

################################################################################
# Now check other hardware configuration
################################################################################
# We should have at least 2 CPUs
CPUs=`lscpu | grep ^CPU\(s\) | awk '{print $2}'`
if [ $CPUs -lt $MinCPUs ]
then
   Msg="ERROR! The VM has only $CPUs CPUs and at least $MinCPUs CPUs are required."
   error=11
   PrintMsg
fi

#------------------------------------------------------------------------------#
# We need at least 4096GB of RAM. Comparison is in Kb. Comparison is in Kb.
#------------------------------------------------------------------------------#
InstalledMemory=`cat /proc/meminfo | grep MemTotal | awk '{print $2}'`
if [ $InstalledMemory -lt $MinMemory ]
then
   Msg="ERROR!  The VM has too little memory. $MinMemory KB is required and only $InstalledMemory KB is present."
   error=12
   PrintMsg
fi

################################################################################
# Check for correct minimum Fedora specs.
################################################################################
#------------------------------------------------------------------------------#
# Check for Fedora
#------------------------------------------------------------------------------#
if [ $Name != "fedora" ]
then
   Msg="ERROR!  This version of Linux is not Fedora. This course requires Fedora."
   error=14
   PrintMsg
fi

#------------------------------------------------------------------------------#
# Check for Fedora 29 or later
#------------------------------------------------------------------------------#
Release=`grep VERSION_ID /etc/os-release | awk -F= '{print $2}'`
if [ $Release -lt $MinRelease ]
then
   Msg="ERROR!  This is Fedora $Release. This course requires Fedora $MinRelease or later."
   error=15
   PrintMsg
fi

#------------------------------------------------------------------------------#
# check for x86_64 (64-bit)
#------------------------------------------------------------------------------#
if ! uname -r | grep x86_64 > /dev/null
then
   Msg="ERROR!  This is not a 64-bit version of Linux. This course requires 64-bit Linux."
   error=16
   PrintMsg
fi

#------------------------------------------------------------------------------#
# Check for the correct hostname
#------------------------------------------------------------------------------#
if [ $Host != $HostName ]
then
   Msg="ERROR!  The VM hostname, $Host, is incorrect. It must be $HostName"
   error=17
   PrintMsg
fi


#------------------------------------------------------------------------------#
# Quit if there are any errors
#------------------------------------------------------------------------------#
if [ $error -gt 0 ]
then
   Quit
fi


################################################################################
# Installing all current updates if not testing and not cleaning up
################################################################################

if [ $Test -eq 0 ] && [ $Clean -eq 0 ]
then
   Msg="Installing all updates."
   PrintMsg
   dnf -y update
else
   Msg="Not installing updates."
   PrintMsg
fi

################################################################################
################################################################################
# Set up state for the beginning of Volume 2
################################################################################
################################################################################
# Are we setting the starting state for Volume 2?
if [ $V2 = "1" ]
then
   Msg="Initiating setup to configure the starting state for Volume 2."
   PrintMsg

   ################################################################################
   # Delete all existing partitions and filesystems for /dev/sdb and create new.
   # WARNING! We must assume that the previous check for the presence of the
   # virtual disk /dev/sdb was correct and that it exists.
   ################################################################################
   Msg="Creating partitions and filesystems on the virtual hard drives"
   PrintMsg
   # Make the drive label
   parted -s /dev/sdb mklabel msdos
   # Create the partitions on /dev/sdb using parted
   parted -s /dev/sdb mkpart primary 1MiB 2000MiB
   parted -s /dev/sdb mkpart primary 2096MiB 4096MiB
   # Create the filesystems
   mkfs.ext4 -F /dev/sdb1
   mkfs.btrfs -f /dev/sdb2
   # Add the label to the ext4 filesystem
   e2label /dev/sdb1 TestFS
   # Create mount points
   mkdir /TestFS
   # Add entries to /etc/fstab if they are not already there
   if ! grep /dev/sdb1 /etc/fstab 
   then
      echo "/dev/sdb1        /TestFS           ext4    defaults        1 2" >> /etc/fstab
   fi
   # Mount the filesystem. 
   mount /TestFS
   # The btrfs system is not mounted nor is an entry in fstab provided.

  

   ################################################################################
   # Creating student users if not already created
   ################################################################################
   for User in $StudentList
   do
      # Add users with password 
      if ! grep "$User:x:" /etc/passwd > /dev/null
         then
         Msg="Adding the user: $User"
         PrintMsg
	 # Call procedure to set user home directory
	 SetUser
         # Add the user
         useradd -c "Student User $User" $User
         # Set the password
         echo "$User:$Password" | chpasswd
         ################################################################################
         # Creating default user directories plus ~/bin for executables
         ################################################################################
         Msg="Creating default directories and files for $User."
         PrintMsg
         cd $UserDir
         mkdir Desktop Documents Downloads Music Pictures Public Templates Videos bin
      else
         Msg="User $User not added. User ID already present."
         PrintMsg
      fi
   done

   ################################################################################
   # Installing RPM packages if not test mode
   ################################################################################
   if [ $Test -eq 0 ]
   then
      Msg="Installing required RPM packages."
      PrintMsg
      dnf -y install $RPMlist1
   else
      Msg="Not installing RPM packages in Test mode."
      PrintMsg
   fi


   ################################################################################
   # Creating directories and files that would be created by the student in 
   # the /home/student home directory
   ################################################################################
   #------------------------------------------------------------------------------#
   # Chapter 7
   #------------------------------------------------------------------------------#
   # Set the user to student
   User="student"
   # Call procedure to set user home directory
   SetUser
   cd $UserDir
   mkdir -p testdir1/testdir2/testdir3/testdir4/testdir5 testdir6 testdir7
   for I in dmesg.txt dmesg1.txt dmesg2.txt dmesg3.txt dmesg4.txt ; do dmesg > $I ; done
   touch newfile.txt
   df -h > diskusage.txt
   echo "hello world" >> dmesg1.txt

   #------------------------------------------------------------------------------#
   # Chapter 9
   #------------------------------------------------------------------------------#
   echo "Hello world" > hello.txt ; echo "How are you?" >> hello.txt
   pwgen 75 5000 > random.txt

   #------------------------------------------------------------------------------#
   # Chapter 13
   #------------------------------------------------------------------------------#
   cd $UserDir
   # Create the cpuHog script using a "here" document. Must be left aligned

   echo '#!/bin/bash' > cpuHog
   echo '# This little program is a cpu hog' >> cpuHog
   echo 'X=0;while [ 1 ] ; do echo $X ; X=$((X+1));done' >> cpuHog

   # Now set the permissions.
   chmod 755 cpuHog

   cd $UserDir
   # Make a FIFO pipe
   mkfifo mypipe

   #------------------------------------------------------------------------------#
   # Chapter 15
   #------------------------------------------------------------------------------#
   mkdir -p $UserDir/testdir/testdir8 && touch $UserDir/testdir/testdir8/testfile1
   chmod 076 testdir
   cd $UserDir/testdir7
   touch {my,your,our}.test.file.{000..200}{a..f}.{txt,asc,file,text}

   #------------------------------------------------------------------------------#
   # Chapter 18
   #------------------------------------------------------------------------------#
   cd $UserDir/Documents
   for I in `seq -w 20`;do dmesg > testfile$I;touch test$I \file$I;done
   echo "Hello world." > file09
   cp file09 /tmp
   cp file09 /home/student1
   chmod 660 /tmp/file09

   # Set up shared directory and group 
   Msg="Set up shared directory and group."
   PrintMsg
   groupadd -g 5000 dev
   usermod -G 5000 student
   usermod -G 5000 student1
   cd /home
   mkdir dev
   chgrp dev dev
   chmod 770 dev
   chmod g+s dev
   cd /home/dev
   echo "Hello World" > file01 ; chown student.dev file01
   echo "Hello to you, too" >> file01
   echo "Hello World" > testfile-01.txt

   # Get back to the student directory
   cd $UserDir
   touch umask.test
   chmod 664 umask.test

   # create some links
   Msg="Creating some hard and soft links."
   PrintMsg
   cd $UserDir/testdir
   echo "Hello World" > file001
   ln file001 link1
   ln link1 link2
   ln -s link1 softlink1
   cd /tmp ; ln -s $UserDir/testdir/file001 softlink2


   ################################################################################
   # Make changes to various configuration files.
   ################################################################################
   #------------------------------------------------------------------------------#
   # Chapter 11
   #------------------------------------------------------------------------------#
   # create some links
   Msg="Changing some configuration files."
   cd $UserDir
   # Make backup of the original sudoers file 
   cp /etc/sudoers /etc/sudoers.bak
   echo "student ALL=/usr/sbin/mii-tool" >> /etc/sudoers

   #------------------------------------------------------------------------------#
   # Chapter 16
   #------------------------------------------------------------------------------#
   cd /etc/default
   # Back up /etc/default/grub
   if [ ! -e grub.bak ]
   then	   
      cp -f grub grub.bak
   fi
   # Change grub parameters
   sed -i -e "s/GRUB_TIMEOUT=5/GRUB_TIMEOUT=10/" -e 's/GRUB_DISABLE_RECOVERY="true"/GRUB_DISABLE_RECOVERY="false"/' -e "s/ rhgb quiet//" grub



   ################################################################################
   # Creating directories and files outside of home directories
   ################################################################################
   #------------------------------------------------------------------------------#
   # Chapter 11
   #------------------------------------------------------------------------------#
   cd $UserDir
   mkdir -p testdir /tmp/testdir
   mkdir /tmp/testdir1
   chmod 000 /tmp/testdir1
   cd /tmp/testdir1
   echo "This is a new file" > testfile.txt


   ################################################################################
   # Installation of RPMFusion repos
   ################################################################################
   #------------------------------------------------------------------------------#
   # Chapter 12
   #------------------------------------------------------------------------------#
   if [ $Test -eq 0 ] && [ $Clean -eq 1 ]
   then
      Msg="Installing RPMFusion repositories for Release $Release."
      PrintMsg
      cd
      wget http://download1.rpmfusion.org/free/fedora/rpmfusion-free-release-$Release.noarch.rpm
      wget http://download1.rpmfusion.org/nonfree/fedora/rpmfusion-nonfree-release-$Release.noarch.rpm
      dnf -y install ./rpmfusion*
      # Remove the RPM package files
      rm -f rpmfusion*rpm
   fi

   ################################################################################
   # Set file ownership for all student users
   ################################################################################
   SetOwnership

fi

################################################################################
################################################################################
# Set up state for the beginning of Volume 3
################################################################################
################################################################################
# Are we setting the starting state for Volume 3?
if [ $V3 = "1" ]
then
   Msg="Initiating setup to configure the starting state for Volume 3."
   PrintMsg

   ################################################################################
   # Installing RPM packages if not test mode
   ################################################################################
   if [ $Test -eq 0 ]
   then
      Msg="Installing required RPM packages."
      PrintMsg
      dnf -y install $RPMlist2
   else
      Msg="Not installing RPM packages in Test mode."
      PrintMsg
   fi


   ################################################################################
   # Make changes and additions to the filesystems
   ################################################################################
   #------------------------------------------------------------------------------#
   # Chapter 1
   #------------------------------------------------------------------------------#
   # Resize /home
   # Extend the LV
   lvextend -L +2G /dev/fedora_studentvm1/home
   # Resize the file system
   resize2fs /dev/fedora_studentvm1/home
   #------------------------------------------------------------------------------#
   # Create a new volume group and volume on /dev/sdb. This VG will use the 
   # existing /dev/sdb2 partition as well as the new /dev/sdb3 partition.
   #------------------------------------------------------------------------------#
   # Create a new primary partition using the rest of the space on /dev/sdb
   parted -s /dev/sdb mkpart primary 4096MiB 19GiB
   # Create physical volumes. Does not matter that sdb2 is btrfs. This deletes that
   # filesystem.
   pvcreate -f /dev/sdb2 /dev/sdb3
   # Crete the new Volume Group
   vgcreate NewVG-01 /dev/sdb2 /dev/sdb3
   # Create a 2GB Logical Volume
   lvcreate -y -L 2G NewVG-01 --name TestVol1
   # Create an EXT4 filesystem
   mkfs -t ext4 /dev/mapper/NewVG--01-TestVol1
   #------------------------------------------------------------------------------#
   # Extend the VG
   #------------------------------------------------------------------------------#
   # Create a new PV on /dev/sdc
   pvcreate /dev/sdc
   # Extend the VG
   vgextend NewVG-01 /dev/sdc
   # Now extend the LV using all the space on the new PV
   lvextend /dev/NewVG-01/TestVol1 /dev/sdc
   # Resize the filesystem
   resize2fs /dev/NewVG-01/TestVol1

   #------------------------------------------------------------------------------#
   # Chapter 3
   #------------------------------------------------------------------------------#
   # Backup master boot record
   dd if=/dev/sda of=/tmp/myMBR.bak bs=512 count=1
   # Although /dev/sdd1 is configured as swap space in V2Ch3, it is later removed 
   # in V2Ch9 so we will not bother creating it in the first place.

   #------------------------------------------------------------------------------#
   # Chapter 5
   #------------------------------------------------------------------------------#
   # Expand swap volume by 2GB
   #------------------------------------------------------------------------------#
   # Turn off the swap volume
   swapoff $SwapVol
   # Delete the logical volume
   lvextend -L +2G /dev/mapper/fedora_studentvm1-swap
   # Make the resized volume into swap space
   mkswap /dev/mapper/fedora_studentvm1-swap
   # Turnm on swap
   swapon -a

   #------------------------------------------------------------------------------#
   # Chapters 7 and 9
   #------------------------------------------------------------------------------#
   # Add directories and files to student user
   #------------------------------------------------------------------------------#
   User="student"
   # Call procedure to set user home directory
   SetUser
   Msg="Creating some additional directories and files for $User."
   PrintMsg
   # Set the user account ID
   cd $UserDir
   # Create the directories and files
   mkdir chapter7 chapter9 Documents/Directory01 Documents/Directory02
   cd $UserDir/chapter9
   # Create some directories
   for Dept in Human-Resources Sales Finance Information-Technology Engineering Administration Research
   do 
      mkdir "$Dept"  
   done 
   # Create the list of RPMs for Experiment 9-17
   for RPM in `rpm -qa | sort | uniq` ; do rpm -qi $RPM ; done | egrep -i "^Name|^Summary" > RPM-summary.txt

   #------------------------------------------------------------------------------#
   # Chapter 10
   #------------------------------------------------------------------------------#
   # Download the doUpdates script.
   #------------------------------------------------------------------------------#
   # Ensure we are in the root home directory
   cd /root
   # Create /root/bin
   mkdir bin
   cd /root/bin
   # Download the file from the Apress GitHub repo
   wget https://raw.githubusercontent.com/Apress/using-and-administering-linux-volume-2/master/doUpdates
   # Set permissions
   chmod 754 doUpdates

   # Return to root home directory
   cd

   ################################################################################
   # Perform some network configuration
   ################################################################################
   #------------------------------------------------------------------------------#
   # Chapter 12
   #------------------------------------------------------------------------------#
   Msg="Creating a network configuration script for enp0s3"
   PrintMsg
   nmcli connection add save yes type ethernet ifname enp0s3 con-name enp0s3

   Msg="Adding a line to the /etc/hosts file."
   PrintMsg
   ip addr show enp0s3 | grep "inet " | awk '{print $2}' | awk -F/ '{print $1"  studentvm1 svm1 vm1 s1"}' >> /etc/hosts


   #------------------------------------------------------------------------------#
   # Chapter 17
   #------------------------------------------------------------------------------#
   #------------------------------------------------------------------------------#
   # Create telnet server xinetd file
   #------------------------------------------------------------------------------#
   cd /etc/xinetd.d
   cat  << xxEOFxx >> telnet
# default: on
# description: The telnet server serves telnet sessions; it uses 
#       unencrypted username/password pairs for authentication.
service telnet
{
         flags           = REUSE
         socket_type     = stream
         wait            = no
         user            = root
         server          = /usr/sbin/in.telnetd
         log_on_failure  += USERID
         disable         = no
 }

xxEOFxx

   # Now add a firewall rule
   firewall-cmd --permanent --add-port=23/tcp
   firewall-cmd --reload

   # Start SSHD
   systemctl start sshd ; systemctl enable sshd

   #------------------------------------------------------------------------------#
   # Convert to IPTables
   #------------------------------------------------------------------------------#
   Msg="Converting to IPTables"
   PrintMsg
   # Create an iptables file

   cd /etc/sysconfig
   cat  << xxEOFxx >> iptables
# Generated by iptables-save v1.8.2 on Mon Oct 28 13:28:49 2019
*filter
:INPUT ACCEPT [0:0]
:FORWARD ACCEPT [0:0]
:OUTPUT ACCEPT [484541:8549549018]
-A INPUT -m state --state RELATED,ESTABLISHED -j ACCEPT
-A INPUT -p icmp -j ACCEPT
-A INPUT -i lo -j ACCEPT
-A INPUT -p tcp -m state --state NEW -m tcp --dport 22 -j ACCEPT
-A INPUT -j REJECT --reject-with icmp-host-prohibited
-A FORWARD -j REJECT --reject-with icmp-host-prohibited
COMMIT
# Completed on Mon Oct 28 13:28:49 2019


xxEOFxx

   cd
   # Stop firewalld
   systemctl stop firewalld ; systemctl disable firewalld
   # Start IPTables
   systemctl start iptables ; systemctl enable iptables
   # Sometimes IPTables does not seem to read the rule file. 
   # This command ensures that it does.
   iptables-restore iptables



   ################################################################################
   # Create a dummy printer
   ################################################################################
   #------------------------------------------------------------------------------#
   # Chapter 7
   #------------------------------------------------------------------------------#
   # Create the dummy printer.
   #------------------------------------------------------------------------------#
   Msg="Creating a dummy printer and queue."
   PrintMsg
   lpadmin -p DummyPrinter -E -v file:/dev/null
   #------------------------------------------------------------------------------#
   # Modify the /etc/cups/cups-pdf.conf file to the use ~/chapter7 directory
   #------------------------------------------------------------------------------#
   sed -i -e 's/^Out ${DESKTOP}/Out ${HOME}\/chapter7/' /etc/cups/cups-pdf.conf
   # Make this the default printer. Mixed case required.
   lpoptions -d Cups-PDF
   lpq

   ################################################################################
   # Set file ownership for all student users
   ################################################################################
   SetOwnership
fi


################################################################################
# Clean the system of installed RPMs and test directories and files. This is
# a hidden option - unless you are a smart SysAdmin and are checking out this
# script.
################################################################################
if [ $Clean -eq 1 ]
then
   Msg="Initiating Cleanup."
   PrintMsg
   # First force the student users off the system. 
   # Now remove the student users.
   for User in $StudentList
   do
      if grep "$User:x:" /etc/passwd > /dev/null
      then
         Msg="Removing user $User."
         PrintMsg
	 # Kill any processes belonging to the user
	 pkill -KILL -U $User
	 # Delete the user account
         userdel -rf $User
      fi
   done 

   # Removing files and directories created on other locations
   Msg="Removing files and directories present elsewhere than in user home directories."
   PrintMsg
   # Make sure we are in root's home directory
   cd
   rm -rf /home/dev
   rm -rf /tmp/testdir /tmp/testdir1
   rm -r /tmp/file*
   rm -f /tmp/softlink2
   rm -f /etc/sysconfig/network-scripts/ifcfg-enp0s3
   rm -rf /root/bin

   # Remove added groups
   groupdel dev

   #------------------------------------------------------------------------------#
   # Revert to firewalld
   #------------------------------------------------------------------------------#
   systemctl stop iptables ; systemctl disable iptables
   systemctl start firewalld ; systemctl enable firewalld
   # Remove the IPTables file
   rm -f /etc/sysconfig/iptables

   ################################################################################
   # Remove Telnet from firewalld
   ################################################################################
   firewall-cmd --permanent --remove-port=23/tcp
   firewall-cmd --reload

   ################################################################################
   # Restore original configuration files
   ################################################################################
   Msg="Restoring the original state of several configuration files"
   PrintMsg
   mv /etc/sudoers.bak /etc/sudoers
   cd /etc/default
   cp -f grub.bak grub
   # Remove the interface config file for enp0s3
   rm -f /etc/sysconfig/network-scripts/ifcfg-enp0s3
   # Restore /etc/hosts
   rm -f /etc/hosts
   cat  << xxEOFxx >> /etc/hosts
127.0.0.1   localhost localhost.localdomain localhost4 localhost4.localdomain4
::1         localhost localhost.localdomain localhost6 localhost6.localdomain6

xxEOFxx

   # Remove telnet server xinetd config file
   rm -f /etc/xinetd.d/telnet

   cd
   ################################################################################
   # Resize /home to original 2GB
   ################################################################################
   Msg="Restoring /home to its original 2GB size."
   PrintMsg
   # unmount the /home directory. All user accounts and home directrories 
   # should already be deleted by the code above.
   umount /home
   # Delete the logical volume
   lvremove -f /dev/fedora_studentvm1/home
   # recreate the /home logical volume at 2GB
   lvcreate -y -L 2G fedora_studentvm1 --name home
   # Add a label
   e2label /dev/fedora_studentvm1/home home
   # Make the filesystem
   mkfs.ext4 -F /dev/fedora_studentvm1/home
   # Mount the re-created /home volume
   mount /home

   ################################################################################
   # Resize swap volume to original 4GB
   ################################################################################
   Msg="Restoring /swap to its original 4GB size."
   PrintMsg
   # Turn off the swap volume
   swapoff $SwapVol
   # Delete the logical volume
   lvremove -f /dev/fedora_studentvm1/swap
   # recreate the swap logical volume at 4GB
   lvcreate -y -L 4G fedora_studentvm1 --name swap
   # Make the swap filesystem
   mkswap $SwapVol
   # turn off swap on /dev/sdd1
   swapoff /dev/sdd1

   ################################################################################
   # Remove all partitions on drives other than /dev/sda
   ################################################################################
   Msg="Removing volume groups and partitions from hard drives."
   PrintMsg
   # Unmount possible mounts
   umount /mnt
   umount /TestFS
   # Remove Volume Group NewVG-01
   vgremove -y /dev/NewVG-01
   # Remove partitions
   for Drive in /dev/sdb /dev/sdd
   do
       for Part in `parted -s $Drive print | awk '{print $1}' | grep ^[1-9]` 
       do 
   #       umount $Drive$Part
          parted $Drive -s rm $Part 
       done
   # Remove entries from /etc/fstab
   sed -i '/sd[bcd]/d' /etc/fstab
   # Delete mount points
   rm -rf /TestFS

   done

   ################################################################################
   # Now remove all of the RPMs we installed if not test mode.
   ################################################################################
   if [ $Test -eq 0 ]
   then
      Msg="Removing RPM packages."
      PrintMsg
      dnf -y remove $RPMlist1
      dnf -y remove $RPMlist2
      # Remove RPMFusion repo packages
      dnf -y remove rpmfusion-*-release
      # Remove RPMs from root home
      cd 
      rm -f *rpm
   else
      Msg="Not removing RPM packages in Test mode."
      PrintMsg
   fi


fi

Quit

################################################################################
# End of program
################################################################################

